#!/usr/bin/env python
# coding: utf-8

# In[1]:


import argparse
import os
import cv2
import numpy as np
import random


# In[2]:


global_image_num = 0
def is_image_file(filename):
    return any(filename.endswith(extension) for extension in ['.png', '.jpg', '.jpeg', '.PNG', '.JPG', '.JPEG'])


# In[3]:


def Pressure_to_Frame(src_file, save_file):
    global global_image_num
    index_frame = 0
    with open(src_file, encoding='utf-8-sig') as f:
        lines = f.readlines()
        frame = []
        for line in lines:
            # 判定每一帧开头,清零索引
            if line[:5] == 'frame':
                index_frame = 0
            # 以空格为分隔导出列表
            marix = line.split()  # 144
            # 判定读取的每行的列表长度是否为帧
            if len(marix) == 144:
                frame.append(marix)
            # 遇到frame 则抽取144行组成一帧
            if index_frame - 144 == 0:
                frame = np.array(frame)
                frame = frame.astype(np.int32)
                # 生成帧的图像名称
                crop_image_name = '{}.jpg'.format(global_image_num)
                # bank+1
                global_image_num += 1
                if global_image_num % 1000 == 0:
                    print(global_image_num, frame.shape)
                # 中文路径图片保存
                
                save_img_path = os.path.join(save_file, crop_image_name)
                cv2.imencode('.jpg', frame)[1].tofile(save_img_path)
                frame = []      
            # 索引加一
            index_frame += 1
            


# In[4]:


# 将Frame文件夹中的帧转化为视频
def Frame_to_Video(video_name, save_frame_path, save_video_path, out_FPS=25):
    size = (144, 144)
    # 完成写入对象的创建

    videowrite = cv2.VideoWriter(os.path.join(save_video_path, video_name), cv2.VideoWriter_fourcc('m', 'p', '4', 'v'),
                                 out_FPS, size)
    print(os.path.join(save_video_path, video_name))

    # 获取帧图片
    image_filenames = [x for x in os.listdir(save_frame_path) if is_image_file(x)]

    c = 0
    # 获取帧总数
    frame_num = len(image_filenames)
    # 遍历文件夹
    for filename in [os.path.join(save_frame_path, '{0}.jpg').format(i) for i in range(frame_num)]:
        # 读取每帧图片
        img = cv2.imread(filename)
        # img = 255 - img

        # 写入视频
        videowrite.write(img)

        c = c + 1
        if c % 600 == 0:
            print('已读取帧数:', c)
        if img is None:
            print(filename + " is error!")
            continue

    videowrite.release()
def Video_FPS_Change(save_frame_path, out_save_path, in_FPS=50, out_FPS=25):
    # 保存帧索引
    # global sort_frame, index_second
    Frame_num = 0

    # 获取帧图片
    image_filenames = [x for x in os.listdir(save_frame_path) if is_image_file(x)]
    # 原始视频每秒帧数读取
    one_second_frame = range(in_FPS)

    index_second = 0
    sort_frame = []
    # 获取帧总数
    frame_num = len(image_filenames)
    # 遍历文件夹,获取每一张帧率图名称
    for filename in range(frame_num):

        if filename % in_FPS == 0:
            # 每秒均匀随机抽帧
            a = random.sample(one_second_frame, out_FPS)
            # 帧排序
            sort_frame = sorted(a)
            # 每一秒的索引
            index_second = 0

        # 若该帧在所抽取的帧里面则保存
        if filename % in_FPS == sort_frame[index_second]:
            # 在索引内索引就+1,否则索引为最后一个值
            if index_second < out_FPS - 1:
                # 索引+1
                index_second += 1
            else:
                index_second = out_FPS - 1

            # 需要读取的图片路径
            img_path = os.path.join(save_frame_path, '{0}.jpg').format(filename)
            # 可以解决中文路径无法读取的问题
            src_image = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), -1)

            crop_image_name = '{}.jpg'.format(Frame_num)
            Frame_num += 1
            # 将图片保存到新目录下
            save_img_path = os.path.join(out_save_path, crop_image_name)
            cv2.imwrite(save_img_path, src_image)
        else:
            pass



# In[5]:


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # 原始阵列数据
    src_txt_path = 'E:\\2'
    parser.add_argument('--src_txt_path', type=str, default=src_txt_path + '\\850.txt')
    # 保存原始帧图片地址
    parser.add_argument('--save_frame_path', type=str,
                        default='E:\\3')
    # 保存视频地址
    parser.add_argument('--save_video_path', type=str,
                        default='E:\\video')
    # 保存抽帧图片地址
    parser.add_argument('--out_frame_path', type=str,
                        default='E:\\3\\out_frame')
    opt = parser.parse_args(args=[])

    # 目录不存在生成目录
    if not os.path.exists(opt.out_frame_path):
        os.makedirs(opt.out_frame_path)

    # 将压力阵列转化为帧
    Pressure_to_Frame(opt.src_txt_path, opt.save_frame_path)
    # 将帧转化为视频
    Frame_to_Video('850.mp4', opt.save_frame_path, opt.save_video_path, out_FPS=50)
    # 改变帧视频帧率
    Video_FPS_Change(opt.save_frame_path, opt.out_frame_path, in_FPS=50, out_FPS=25)
    # 将帧转化为视频
    Frame_to_Video('850.mp4', opt.out_frame_path, opt.save_video_path, out_FPS=25)

